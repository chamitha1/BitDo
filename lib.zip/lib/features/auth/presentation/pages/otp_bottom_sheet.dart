import 'dart:async';
import 'package:BitOwi/constants/sms_constants.dart';
import 'package:BitOwi/core/widgets/custom_snackbar.dart';
import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';

class OtpBottomSheet extends StatefulWidget {
  final String email;
  final int otpLength;
  final SmsBizType bizType;

  final Future<bool> Function(String pin) onVerifyPin;
  final VoidCallback onVerified;
  final Future<bool> Function()? onResend;

  const OtpBottomSheet({
    super.key,
    required this.email,
    required this.bizType,
    required this.onVerifyPin,
    required this.onVerified,
    this.onResend,
    this.otpLength = 6,
  });

  @override
  State<OtpBottomSheet> createState() => _OtpBottomSheetState();
}

class _OtpBottomSheetState extends State<OtpBottomSheet> {
  final TextEditingController _pinController = TextEditingController();

  int _secondsRemaining = 35;
  Timer? _timer;
  bool _canResend = false;

  bool _isVerifying = false;
  bool _isResending = false;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pinController.dispose();
    super.dispose();
  }

  void _startTimer() {
    _timer?.cancel();
    setState(() {
      _secondsRemaining = 35;
      _canResend = false;
    });

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;

      setState(() {
        if (_secondsRemaining > 0) {
          _secondsRemaining--;
        } else {
          _canResend = true;
          timer.cancel();
        }
      });
    });
  }

  String get _obfuscatedEmail {
    final parts = widget.email.split('@');
    if (parts.length != 2) return widget.email;

    final name = parts[0];
    final domain = parts[1];
    if (name.length <= 2) return widget.email;

    final firstLetter = name.substring(0, 1);
    final lastLetter = name.substring(name.length - 1);
    final stars = '*' * (name.length - 2);
    return '$firstLetter$stars$lastLetter@$domain';
  }

  Future<void> _verify() async {
    final pin = _pinController.text.trim();

    if (pin.length != widget.otpLength) {
      CustomSnackbar.showError(title: "Error", message: "Please enter valid OTP");
      return;
    }

    setState(() => _isVerifying = true);

    try {
      final ok = await widget.onVerifyPin(pin);
      if (!mounted) return;

      if (ok) {
        widget.onVerified();
      } else {
        CustomSnackbar.showError(
          title: "Error",
          message: "Invalid OTP, please try again.",
        );
      }
    } catch (e) {
      if (!mounted) return;
      CustomSnackbar.showError(
        title: "Error",
        message: "OTP verification failed: $e",
      );
    } finally {
      if (mounted) setState(() => _isVerifying = false);
    }
  }

  Future<void> _resend() async {
    if (!_canResend || _isResending) return;

    setState(() => _isResending = true);

    try {
      if (widget.onResend != null) {
        final ok = await widget.onResend!();
        if (!mounted) return;

        if (ok) {
          _startTimer();
          CustomSnackbar.showSuccess(
            title: "Success",
            message: "OTP resent successfully.",
          );
        } else {
          CustomSnackbar.showError(
            title: "Error",
            message: "Failed to resend OTP. Try again.",
          );
        }
      } else {
        _startTimer();
      }
    } catch (e) {
      if (!mounted) return;
      CustomSnackbar.showError(title: "Error", message: "Resend failed: $e");
    } finally {
      if (mounted) setState(() => _isResending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final viewInsets = MediaQuery.of(context).viewInsets;
    final size = MediaQuery.of(context).size;

    final defaultPinTheme = PinTheme(
      width: widget.otpLength == 6 ? 45 : 56,
      height: 56,
      textStyle: const TextStyle(
        fontSize: 22,
        color: Color(0xFF151E2F),
        fontWeight: FontWeight.w600,
      ),
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0xffE1E1EC)),
        borderRadius: BorderRadius.circular(16),
        color: Colors.white,
      ),
    );

    final focusedPinTheme = defaultPinTheme.copyDecorationWith(
      border: Border.all(color: const Color(0xFF2F5599)),
    );

    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.only(bottom: viewInsets.bottom),
        child: Container(
          constraints: BoxConstraints(
            maxHeight: size.height * 0.88,
          ),
          padding: const EdgeInsets.all(24.0),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(32),
              topRight: Radius.circular(32),
            ),
          ),
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(height: 12),
                Image.asset(
                  "assets/icons/verify_email/shield.png",
                  height: 64,
                  width: 64,
                ),
                const SizedBox(height: 20),
                const Text(
                  "Enter Verification Code",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: Color(0xff151E2F),
                    fontFamily: 'Inter',
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Verification code has been send to\n$_obfuscatedEmail",
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 16,
                    color: Color(0xff454F63),
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w400,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 24),

                Pinput(
                  length: widget.otpLength,
                  controller: _pinController,
                  defaultPinTheme: defaultPinTheme,
                  focusedPinTheme: focusedPinTheme,
                  showCursor: true,
                  onCompleted: (_) => _verify(),
                ),

                const SizedBox(height: 24),

                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xff1D5DE5),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ElevatedButton(
                      onPressed: _isVerifying ? null : _verify,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: _isVerifying
                          ? const SizedBox(
                              height: 18,
                              width: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Text(
                              "Verify",
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                            ),
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "Didn’t receive code? ",
                      style: TextStyle(
                        color: Color(0xff313832),
                        fontSize: 14,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    // GestureDetector(
                    //   onTap: (_canResend && !_isResending) ? _resend : null,
                    //   child: Text(
                    //     _isResending ? "Resending..." : "Resend OTP",
                    //     style: TextStyle(
                    //       color: (_canResend && !_isResending)
                    //           ? const Color(0xFF1D5DE5)
                    //           : Colors.grey,
                    //       fontWeight: FontWeight.w400,
                    //       fontSize: 14,
                    //     ),
                    //   ),
                    // ),
                    GestureDetector(
                      onTap: (_canResend && !_isResending) ? _resend : null,
                      child: Text(
                        _isResending ? "Resending..." : "Resend OTP",
                        style: const TextStyle(
                          color: Color(0xFF1D5DE5),
                          fontWeight: FontWeight.w400,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    if (!_canResend)
                      Text(
                        " 00:${_secondsRemaining.toString().padLeft(2, '0')}",
                        style: const TextStyle(
                          fontFamily: 'Inter',
                          color: Color(0xff313832),
                          fontSize: 14,
                        ),
                      ),
                  ],
                ),

                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }
}